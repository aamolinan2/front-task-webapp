
export interface Task {
  id: string;
  title: string;
  description: string;
  created_at: string;
  completed: boolean;
}
