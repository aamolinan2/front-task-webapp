
export const environment = {
  production: true,
  apiUrl: 'https://us-central1-task-webapp-66e75.cloudfunctions.net/api'
};
